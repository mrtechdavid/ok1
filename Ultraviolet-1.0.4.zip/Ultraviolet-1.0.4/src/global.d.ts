declare const __uv$config: import('./uv').UVConfig;
